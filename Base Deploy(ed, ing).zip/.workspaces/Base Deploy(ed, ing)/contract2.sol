// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract PersonalRegistry {
    string public builderName = "fadlir nyarmir";
    string public basename = "fadlirnyarmir.base.eth";
    uint256 public registeredAt;

    constructor() {
        registeredAt = block.timestamp;
    }
}