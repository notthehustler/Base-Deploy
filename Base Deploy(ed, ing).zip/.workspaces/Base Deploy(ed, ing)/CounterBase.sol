// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract Counter {
    uint256 public count = 0;
    address public owner;

    constructor() {
        owner = msg.sender;
    }

    function increment() public {
        count += 1;
    }

    function decrement() public {
        require(count > 0, "Already zero");
        count -= 1;
    }

    function reset() public {
        require(msg.sender == owner, "Not owner");
        count = 0;
    }
}