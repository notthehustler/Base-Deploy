// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract HelloBase {
    string public message = "Hello Base!";
    address public owner;

    constructor() {
        owner = msg.sender;
    }
}